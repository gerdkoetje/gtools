regex.py
--------

Function: checktags
This function matches any tags like ##TAGNAME##
if there any wrong tags it returns false else it returns true